import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

# Small sample dataset: hours studied -> exam score
data = pd.DataFrame({
    "hours": [1, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10],
    "score": [35, 41, 47, 50, 52, 58, 60, 64, 63, 70, 72, 74, 79, 80, 85, 86, 90, 93],
})
data.to_csv("study_data.csv", index=False)

X = data[["hours"]]
y = data["score"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)

r2_train = model.score(X_train, y_train)
r2_test = r2_score(y_test, pred)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))

print(f"Equation: score = {model.intercept_:.2f} + {model.coef_[0]:.2f} * hours")
print(f"R2 (train): {r2_train:.3f}")
print(f"R2 (test):  {r2_test:.3f}")
print(f"MAE (test): {mae:.2f} points")
print(f"RMSE (test): {rmse:.2f} points")

# Plot
line_x = np.linspace(0.5, 10.5, 100).reshape(-1, 1)
line_y = model.predict(pd.DataFrame(line_x, columns=["hours"]))

plt.figure(figsize=(8, 5))
plt.scatter(X_train, y_train, color="#2a6fdb", label="Training data", s=60)
plt.scatter(X_test, y_test, color="#e07b00", marker="s", label="Test data", s=70)
plt.plot(line_x, line_y, color="#d62728", linewidth=2,
         label=f"Regression line (R² test = {r2_test:.2f})")
plt.xlabel("Hours studied")
plt.ylabel("Exam score")
plt.title("Simple Linear Regression: Study Hours vs Exam Score")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig("regression_plot.png", dpi=150)
